import React from "react";
import classes from "../styles/Header.module.css";

function Header() {
  return (
    <div className={classes.container}>
      <div>Header</div>
    </div>
  );
}

export default Header;
