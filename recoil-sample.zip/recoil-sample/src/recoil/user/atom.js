import { atom } from "recoil";

export const userListAtomState = atom({
  key: "userListAtomState",
  default: [],
});
