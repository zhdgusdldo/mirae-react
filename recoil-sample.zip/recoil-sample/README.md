# Vite + React + Recoil 샘플 프로젝트

## 실행하는 법

```bash
npm i
npm run dev
```
